import scrapy
from scrapy_splash import SplashRequest
import json

class MuseumSpider(scrapy.Spider):
    name = "museum"
    allowed_domains = ["museumsofindia.gov.in"]
    start_urls = [
"https://museumsofindia.gov.in/repository/record/nkm_hyd-mar-scu-0114-102",
"https://museumsofindia.gov.in/repository/record/nkm_hyd-mar-scu-0115-103",
"https://museumsofindia.gov.in/repository/record/nkm_hyd-mar-scu-0116-104",
"https://museumsofindia.gov.in/repository/record/nkm_hyd-mar-scu-0117-105",
"https://museumsofindia.gov.in/repository/record/nkm_hyd-mar-scu-0118-106",

        
    ]
    
    # Define a start_requests function to connect scrapy and splash
    def start_requests(self):
        # Define the Lua script if it's required
        lua_script = """
            function main(splash, args)
                assert(splash:go(args.url))
                assert(splash:wait(20))
                return {
                    html = splash:html(),
                }
            end
        """
        
        for url in self.start_urls:
            yield SplashRequest(
                url=url,
                callback=self.parse,
                endpoint='execute',
                args={'lua_source': lua_script}
            )

    # Parse method to extract data
    def parse(self, response):
        # Extracting table data
        rows = response.xpath('//*[@id="mCSB_1_container"]/table/tbody/tr')
        table_data = {}
        for row in rows:
            th_text = row.xpath('./th/text()').get().strip()
            td_text = row.xpath('./td/text()').get().strip()
            table_data[th_text] = td_text
        
        # Extracting image URLs
        image_urls = response.xpath('//div[@class="carousel-inner"]//img/@src').getall()
        
        # Constructing full image URLs
        full_image_urls = [response.urljoin(url) for url in image_urls]
        
        # Yielding table data and image URLs
        yield {
            'table_data': table_data,
            'image_urls': full_image_urls
        }

# Run the spider
if __name__ == "__main__":
    from scrapy.crawler import CrawlerProcess

    process = CrawlerProcess(settings={
        'USER_AGENT': 'Mozilla/5.0',
        'ROBOTSTXT_OBEY': False,
        'DOWNLOAD_DELAY': 30,  # Add a delay between requests
        'LOG_ENABLED': True,  # Enable logging
        'SPLASH_URL': 'http://localhost:8050',  # Splash instance URL
        'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        'HTTPCACHE_STORAGE': 'scrapy_splash.SplashAwareFSCacheStorage'
    })

    process.crawl(MuseumSpider)
    process.start()
