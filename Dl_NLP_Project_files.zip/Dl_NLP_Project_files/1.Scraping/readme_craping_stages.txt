Scraping_process: 
1.create environment
2.install libraries
3.using x_path of site, edit in nlp02 > museum.py4
#for convenience scraping is done in multiple stages, first load 5 -5 links seperately 
4.final scraped data is in Data_scraped

Following lines provide training on how to use LUA language and scrape data:


install docker and rung the following command in docker: 
---------------------------------------------------------------

docker pull scrapinghub/splash              #start image of splash in docker
docker run -it -p 8050:8050 scrapinghub/splash  #server listening 
next time: open docker and just run  the play button, copy paste ip address into browser to see lua scraping website interface in browser 
---------------------------------------------------------------

#lua programming language which is to be written in the website 

---------------------------------------------------------------
write link in blank :
---------------------------------------------------------------
function main(splash,args)
    url=args.url
    splash:go(url)
    return splash:png
end


---------------------------------------------------------------
function main(splash,args)
    url=args.url
    splash:go(url)
    return splash:html()
end

---------------------------------------------------------------

function main(splash,args)
    url=args.url
    splash:go(url)
    return {
        html = splash:html(),
        png = splash:png(), 
    }
end

---------------------------------------------------------------
#if you write google.com123 --> it will give error image 


---------------------------------------------------------------
function main(splash,args)
    url=args.url
    assert(splash:go(url))
    assert(splash:wait(2))
    return {
        html = splash:html(),
        png = splash:png(),
    }
end

---------------------------------------------------------------
HTTPS error mesage will come based  on assert , wait waits for site to load 

---------------------------------------------------------------


interacting with new website: 

function main(splash,args)
    url=args.url
    assert(splash:go(url))
    assert(splash:wait(2))

    input_box=assert(splash:select("#id_of_element" ))
    input_box:focus()
    input_box:send_text("book")
    assert(splash:wait(2))
    
    button=assert(splash:("#search_button_css_selector"))
    button:mouse_click()
    assert(splash:wait(6))

    return {
        html = splash:html(),
        png = splash:png(),
    }
end

---------------------------------------------------------------


check if website has javascript or not based on setting > preferences > debugger > disable java script off / on 


---------------------------------------------------------------

paste link of the website : example https://www.adamchoi.co
---------------------------------------------------------------
function main(splash, args )

    splash.private_mode_enabled =false

    assert(splash:go(args.url))
    assert(splash:wait(2))

    all_matches=assert(splash:select_all(" copy_paste_css_selector and replace space with " . " "))
    all_matches[2]:mouse_click()
    assert(splash:wait(3))
    splash:set_viewport_full()
    return {
         splash:png(), splash:html()
    }
end    
---------------------------------------------------------------
-> css selector are written based on tag name or classname

---------------------------------------------------------------

-- website -> https://www.adamchoi.co.uk/overs/detailed

function main(splash, args)
    -- If a website doesn't render correctly, disabling Private mode might help
    splash.private_mode_enabled = false
    -- Go to the URL set on the splash browser and then wait 3 seconds to let the page render
    assert(splash:go(args.url))
    assert(splash:wait(3))
    -- Select all the elements that have the css selector "label.btn.btn-sm.btn-primary"
    all_matches = assert(splash:select_all("label.btn.btn-sm.btn-primary"))
    -- Two elements were selected. We want to click on the second button, then wait 3 seconds to let the page render
    all_matches[2]: mouse_click()
    assert (splash:wait(3))
    -- Increase the viewport to make all the content visible
    splash: set_viewport_full()
    return {splash: png(), splash: html()}
end
---------------------------------------------------------------

check if website has javascript or not based on setting > preferences > debugger > disable java script off / on



run following commands in terminal: 
-m venv my_scraping_venv
my_scraping_venv\Scripts\activate
pip install scrapy
pip install scrapy-splash
----------------------------------------
scrapy startproject museums
cd museums
scrapy genspider museums https://museumsofindia.gov.in/repository/collection/ObjectType?museum=nkm_hyd
----------------------------------------
# Path: museums/museums/spiders/museums.py
import scrapy
from scrapy_splash import SplashRequest
----------------------------------------

SPLASH_URL = 'http://localhost:8050' to be added in settings.py file

----------------------------------------
in middlewares.py file add the following code:
----------------------------------------

SPLASH_URL = 'http://localhost:8050'
DOWNLOADER_MIDDLEWARES = {
    'scrapy_splash.SplashCookiesMiddleware': 723,
    'scrapy_splash.SplashMiddleware': 725,
    'scrapy.downloadermiddlewares.httpcompression.HttpCompressionMiddleware': 810,
}

SPIDER_MIDDLEWARES = {
    'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
}

DUPEFILTER_CLASS = 'scrapy_splash.SplashAwareDupeFilter'


----------------------------------------

scrapy crawl museum
----------------------------------------

scrapy crawl museum -o trail.json

----------------------------------------

adding user agent:

type the following : 
----------------------------------------

    splash:set_user_agent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3')
    
----------------------------------------