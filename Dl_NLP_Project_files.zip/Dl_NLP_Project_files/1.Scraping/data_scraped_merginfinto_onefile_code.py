import os
import json

# Path to the folder containing the JSON files
folder_path = "Data_scraped"

# List to hold the contents of all JSON files
data = []

# Iterate over all files in the folder
for filename in os.listdir(folder_path):
    if filename.endswith(".json"):
        file_path = os.path.join(folder_path, filename)
        with open(file_path, "r") as file:
            # Load the JSON content of the file and append it to the data list
            file_data = json.load(file)
            data.append(file_data)

# Path to the output JSON file
output_file = "merged_data.json"

# Write the merged data to the output file
with open(output_file, "w") as out_file:
    json.dump(data, out_file, indent=4)

print("Merged data saved to:", output_file)
