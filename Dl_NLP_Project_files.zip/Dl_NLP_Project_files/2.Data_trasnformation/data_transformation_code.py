import pandas as pd
import json

def convert_csv_to_json(csv_path, output_json_path):
    # Load the csv file
    data = pd.read_csv(csv_path,encoding='utf-8')
    
    # Prepare the structured data list
    formatted_data = []

    for idx, row in data.iterrows():
        messages = []
        images = []
        image_index = 0  # To track the index of images in the conversation

        # Iterate through each question-answer pair and format it into the required structure
        for i in range(15):  # Assuming there are 15 question-answer pairs
            user_col = f'User.{i}' if i > 0 else 'User'
            assistant_col = f'Assistant.{i}' if i > 0 else 'Assistant'
            if user_col in row and assistant_col in row:
                question = row[user_col].strip() if pd.notna(row[user_col]) else ""
                answer = row[assistant_col].strip() if pd.notna(row[assistant_col]) else ""
                
                # Add user's question and image reference (if first question)
                user_message = {
                    "role": "user",
                    "content": [
                        {"index": None, "text": question, "type": "text"}
                    ]
                }
                if i == 0:  # Assume the image is always referenced in the first user question
                    user_message["content"].append({"index": image_index, "text": None, "type": "image"})
                    images.append(row['Local_image_path'].strip() if pd.notna(row['Local_image_path']) else None)
                    image_index += 1
                
                # Add assistant's answer
                assistant_message = {
                    "role": "assistant",
                    "content": [
                        {"index": None, "text": answer, "type": "text"}
                    ]
                }
                
                messages.append(user_message)
                messages.append(assistant_message)

        # Combine everything into a single entry
        entry = {
            "messages": messages,
            "images": images
        }
        
        formatted_data.append(entry)

    # Save the structured data to a JSON file
    with open(output_json_path, 'w') as json_file:
        json.dump(formatted_data, json_file, indent=4)

# Specify your csv path and output JSON path
csv_path = 'User_assistant_Q&A_data_input.csv'
output_json_path = 'C:\\Users\\GURU\\Desktop\\new\\data_transformation\\training_dataset_final_json.json'

# Call the function to convert and save the data
convert_csv_to_json(csv_path, output_json_path)